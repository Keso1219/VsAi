import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Category } from '../data/categories';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <div className="bg-dark-card rounded-lg shadow-card overflow-hidden transform transition-all hover:translate-y-[-4px] hover:shadow-lg">
      <div className="p-6">
        <div className="flex items-center mb-4">
          <img 
            src={category.iconUrl} 
            alt={`${category.name} icon`} 
            className="w-12 h-12 mr-4"
          />
          <h3 className="text-xl font-semibold text-white">{category.name}</h3>
        </div>
        
        <p className="text-secondary mb-6 line-clamp-3">
          {category.description}
        </p>
        
        <Link 
          to={`/categories/${category.slug}`}
          className="inline-flex items-center text-primary hover:text-primary-hover transition-colors"
        >
          <span className="mr-2">View Tools</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};

export default CategoryCard;