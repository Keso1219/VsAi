import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Search } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <div className="py-16 md:py-24 text-center">
      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
        Find the perfect AI tool <span className="text-primary">in seconds</span>
      </h1>
      <p className="text-lg md:text-xl text-secondary max-w-3xl mx-auto mb-10">
        Discover and compare the best AI tools for your specific needs. 
        From content creation to coding assistance, we've curated the most effective tools available.
      </p>

      <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
        <Link
          to="/categories"
          className="flex items-center justify-center bg-primary hover:bg-primary-hover text-white font-medium py-3 px-6 rounded-lg transition-colors"
        >
          <span className="mr-2">Browse Categories</span>
          <ArrowRight className="w-5 h-5" />
        </Link>
        <Link
          to="/tools"
          className="flex items-center justify-center bg-dark-card hover:bg-gray-800 text-white font-medium py-3 px-6 rounded-lg transition-colors"
        >
          <span className="mr-2">All Tools</span>
          <Search className="w-5 h-5" />
        </Link>
      </div>

      <div className="text-sm text-secondary">
        <p>Curated collection of {60}+ AI tools across {8} categories</p>
      </div>
    </div>
  );
};

export default HeroSection;