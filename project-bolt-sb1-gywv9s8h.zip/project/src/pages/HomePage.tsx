import React from 'react';
import { Link } from 'react-router-dom';
import { categories } from '../data/categories';
import CategoryCard from '../components/CategoryCard';
import HeroSection from '../components/HeroSection';
import HowItWorks from '../components/HowItWorks';
import { ArrowRight } from 'lucide-react';

const HomePage: React.FC = () => {
  // Get featured categories or first 4 if none are marked as featured
  const featuredCategories = categories.filter(cat => cat.featured).length > 0 
    ? categories.filter(cat => cat.featured)
    : categories.slice(0, 4);

  return (
    <div>
      <HeroSection />
      
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Categories</h2>
              <p className="text-secondary">Explore our most popular AI tool categories</p>
            </div>
            <Link 
              to="/categories"
              className="inline-flex items-center text-primary hover:text-primary-hover transition-colors mt-4 md:mt-0"
            >
              <span className="mr-2">View All Categories</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredCategories.map(category => (
              <CategoryCard key={category.slug} category={category} />
            ))}
          </div>
        </div>
      </section>
      
      <HowItWorks />
      
      <section className="py-16 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-6">Ready to find your perfect AI tool?</h2>
          <p className="text-secondary max-w-2xl mx-auto mb-10">
            Browse our complete collection of AI tools and discover the perfect solution for your needs.
          </p>
          <Link
            to="/tools"
            className="inline-flex items-center bg-primary hover:bg-primary-hover text-white font-medium py-3 px-8 rounded-lg transition-colors"
          >
            <span className="mr-2">See All Tools</span>
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;