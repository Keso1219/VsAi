import React, { useState } from 'react';
import { tools } from '../data/tools';
import ToolCard from '../components/ToolCard';
import FilterBar from '../components/FilterBar';

const AllToolsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [pricingFilter, setPricingFilter] = useState('');
  
  // Filter tools by search query, category, and pricing
  const filteredTools = tools
    .filter(tool => 
      tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.shortDesc.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .filter(tool => categoryFilter ? tool.categorySlug === categoryFilter : true)
    .filter(tool => pricingFilter ? tool.pricing === pricingFilter : true);
  
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">All AI Tools</h1>
        <p className="text-secondary">Browse our comprehensive collection of AI tools</p>
      </div>
      
      <FilterBar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        categoryFilter={categoryFilter}
        setCategoryFilter={setCategoryFilter}
        pricingFilter={pricingFilter}
        setPricingFilter={setPricingFilter}
      />
      
      {filteredTools.length === 0 ? (
        <div className="text-center py-12 bg-dark-card rounded-lg">
          <p className="text-xl text-secondary">No tools match your search criteria</p>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredTools.map(tool => (
            <ToolCard key={tool.slug} tool={tool} />
          ))}
        </div>
      )}
      
      <div className="mt-8 pt-8 border-t border-gray-800 text-center text-secondary text-sm">
        <p>Showing {filteredTools.length} of {tools.length} tools</p>
      </div>
    </div>
  );
};

export default AllToolsPage;