import React, { useState } from 'react';
import { categories } from '../data/categories';
import CategoryCard from '../components/CategoryCard';
import { Search } from 'lucide-react';

const CategoriesPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredCategories = categories.filter(category => 
    category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    category.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Explore All AI Categories</h1>
        <p className="text-secondary">Find the perfect tools for your specific needs</p>
      </div>
      
      <div className="mb-8 relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-500" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search categories..."
          className="block w-full bg-dark-card border border-gray-800 rounded-md py-3 pl-10 pr-3 text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
        />
      </div>
      
      {filteredCategories.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-xl text-secondary">No categories match your search</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
          {filteredCategories.map(category => (
            <CategoryCard key={category.slug} category={category} />
          ))}
        </div>
      )}
    </div>
  );
};

export default CategoriesPage;