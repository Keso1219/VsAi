export interface Category {
  slug: string;
  name: string;
  description: string;
  iconUrl: string;
  featured?: boolean;
}

export const categories: Category[] = [
  {
    slug: 'presentation',
    name: 'Presentation',
    description: 'AI-powered tools for creating stunning presentations and slide decks.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/presentation.png',
    featured: true,
  },
  {
    slug: 'website',
    name: 'Website',
    description: 'Build professional websites quickly with AI assistance.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/web.png',
    featured: true,
  },
  {
    slug: 'writing',
    name: 'Writing',
    description: 'AI tools for content creation, copywriting, and creative writing.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/pen.png',
    featured: true,
  },
  {
    slug: 'ai-model',
    name: 'AI Model',
    description: 'No-code platforms for training and deploying custom AI models.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/artificial-intelligence.png',
    featured: true,
  },
  {
    slug: 'meeting-productivity',
    name: 'Meeting Productivity',
    description: 'AI tools for transcription, note-taking, and meeting summaries.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/meeting.png',
  },
  {
    slug: 'chatbot',
    name: 'Chatbot',
    description: 'Build and deploy AI chatbots for various platforms.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/chat.png',
  },
  {
    slug: 'automation',
    name: 'Automation',
    description: 'Automate workflows and tasks with AI assistance.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/process.png',
  },
  {
    slug: 'ui-ux',
    name: 'UI/UX',
    description: 'AI-powered tools for design and prototyping.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/design.png',
  },
  {
    slug: 'image-generation',
    name: 'Image Generation',
    description: 'Create stunning images and artwork with AI.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/image.png',
  },
  {
    slug: 'video',
    name: 'Video',
    description: 'AI tools for video creation and editing.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/video.png',
  },
  {
    slug: 'design',
    name: 'Design',
    description: 'AI-powered tools for graphic design and visual content.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/design.png',
  },
  {
    slug: 'marketing',
    name: 'Marketing',
    description: 'AI tools for digital marketing and advertising.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/marketing.png',
  },
  {
    slug: 'social-media',
    name: 'Social Media',
    description: 'AI tools for social media management and content creation.',
    iconUrl: 'https://img.icons8.com/fluency/48/000000/social-media.png',
  },
];